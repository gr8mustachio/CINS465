from django.apps import AppConfig


class WorkoutsConfig(AppConfig):
    name = 'workouts'
